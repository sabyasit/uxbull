# AI Agents MCP Server

A Model Context Protocol (MCP) server that provides detailed information about various AI agents and their capabilities.

## Overview

This MCP server exposes a collection of AI agents through the MCP resource system. Each agent has detailed information about their role, capabilities, specializations, and status.

## Available Agents

The server currently provides information about 7 AI agents:

1. **Planning Agent** - Software Architecture & Design
2. **Coding Agent** - Software Development & Implementation
3. **Testing Agent** - Quality Assurance & Testing
4. **Documentation Agent** - Technical Writing & Documentation
5. **DevOps Agent** - Deployment & Operations
6. **Security Agent** - Security Analysis & Hardening
7. **Data Agent** - Data Engineering & Analytics

## Installation

Install dependencies:

```bash
npm install
```

Build the TypeScript code:

```bash
npm run build
```

## Usage

### Running the Server

Build and run the server:

```bash
npm start
```

### Development Mode

For development with automatic TypeScript execution:

```bash
npm run dev
```

The server runs on stdio transport and is designed to be used with MCP clients like Claude Desktop.

### Configuring with Claude Desktop

Add the following to your Claude Desktop MCP configuration file:

**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "ai-agents": {
      "command": "node",
      "args": ["c:\\Users\\sabya\\source\\repos\\MCP\\dist\\index.js"]
    }
  }
}
```

> **Note**: Update the path in `args` to match your actual installation directory.

## Resources Exposed

The server exposes the following resources:

### List All Agents
- **URI**: `agent://list` or `agents://list`
- **Returns**: JSON with all agents and their complete details

### Individual Agent Details
- **URI Pattern**: `agent://{agent-id}`
- **Example URIs**:
  - `agent://planning-agent`
  - `agent://coding-agent`
  - `agent://testing-agent`
  - `agent://documentation-agent`
  - `agent://devops-agent`
  - `agent://security-agent`
  - `agent://data-agent`

## Agent Data Structure

Each agent includes:

- **id**: Unique identifier
- **name**: Display name of the agent
- **role**: Primary function/responsibility
- **capabilities**: Array of what the agent can do
- **specialization**: Array of areas of expertise
- **status**: Current availability status
- **version**: Agent version number
- **createdDate**: When the agent was created

## Example Response

```json
{
  "id": "coding-agent",
  "name": "Coding Agent",
  "role": "Software Development & Implementation",
  "capabilities": [
    "Code implementation in multiple languages",
    "Debugging and troubleshooting",
    "Code refactoring",
    "API development",
    "Database design and optimization"
  ],
  "specialization": [
    "JavaScript/TypeScript",
    "Python",
    "Java",
    "C#",
    "Full-stack development"
  ],
  "status": "active",
  "version": "3.1",
  "createdDate": "2024-01-20"
}
```

## Development

### Project Structure

```
MCP/
├── src/
│   └── index.ts          # Main MCP server implementation (TypeScript)
├── dist/                 # Compiled JavaScript output
│   └── index.js
├── tsconfig.json         # TypeScript configuration
├── package.json          # Project dependencies
└── README.md             # This file
```

### Dependencies

**Runtime:**
- `@modelcontextprotocol/sdk`: Official MCP SDK for building servers

**Development:**
- `typescript`: TypeScript compiler
- `tsx`: TypeScript executor for development
- `@types/node`: TypeScript definitions for Node.js

## License

ISC
