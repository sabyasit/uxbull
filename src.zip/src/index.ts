import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import * as z from 'zod/v4';
import express from 'express';
import { readdir, readFile } from 'fs/promises';
import { join, dirname, basename } from 'path';
import { fileURLToPath } from 'url';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Create an MCP server
const server = new McpServer({
    name: 'demo-server',
    version: '1.0.0'
});

// Add orchestrator instructions tool
server.registerTool(
    'instructions-to-convert-openapi-to-aspnet-web-api',
    {
        title: 'Instructions to Convert OpenAPI to ASP.NET Web API',
        description: 'Instructions to Convert OpenAPI to ASP.NET Web API with 9 specialized agents',
        inputSchema: {},
        outputSchema: { instructions: z.string() }
    },
    async () => {
        try {
            // Read the ORCHESTRATOR.md file
            const orchestratorPath = join(__dirname, '..', 'ORCHESTRATOR.md');
            const content = await readFile(orchestratorPath, 'utf-8');

            let instructions = content;
            const output = {
                instructions
            };

            return {
                content: [{ type: 'text', text: instructions }],
                structuredContent: output
            };
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            const output = {
                instructions: `Error reading ORCHESTRATOR.md: ${errorMessage}`
            };
            return {
                content: [{ type: 'text', text: output.instructions }],
                structuredContent: output
            };
        }
    }
);
// Wrap initialization in an async IIFE to handle top-level await
(async () => {
    const agentsDir = join(__dirname, '..', 'agents');
    const agentFiles = await readdir(agentsDir);

    for (const file of agentFiles) {
        if (file.endsWith('.md')) {
            const agentName = basename(file, '.md');
            // Assuming a format like 'XX-agent-name.md' where XX is a number
            const uriName = agentName.replace(/^\d{2}-/, ''); // Remove leading 'XX-'
            const title = uriName.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '); // Convert to Title Case
            const description = `Instructions for the ${title} agent.`; // Generic description

            server.registerResource(
                uriName,
                `agent://${uriName}`,
                {
                    title: title,
                    description: description,
                    mimeType: 'text/plain'
                },
                async (uri) => {
                    const agentPath = join(agentsDir, file);
                    const content = await readFile(agentPath, 'utf-8');
                    return {
                        contents: [
                            {
                                uri: uri.href,
                                text: content
                            }
                        ]
                    };
                }
            );
        }
    }

    // Set up Express and HTTP transport
    const app = express();
    app.use(express.json());

    app.post('/mcp', async (req, res) => {
        // Create a new transport for each request to prevent request ID collisions
        const transport = new StreamableHTTPServerTransport({
            sessionIdGenerator: undefined,
            enableJsonResponse: true
        });

        res.on('close', () => {
            transport.close();
        });

        await server.connect(transport);
        await transport.handleRequest(req, res, req.body);
    });

    const port = parseInt(process.env.PORT || '3000');
    app.listen(port, () => {
        console.log(`Demo MCP Server running on http://localhost:${port}/mcp`);
    }).on('error', error => {
        console.error('Server error:', error);
        process.exit(1);
    });
})();