# ASP.NET Web API Generator - Agent Orchestrator

## Overview

This orchestrator coordinates 9 specialized agents that work together to parse an OpenAPI specification and generate a complete, production-ready ASP.NET Web API application with .NET 8, Entity Framework Core, SQL Server, JWT authentication, and comprehensive testing.

## Architecture

```mermaid
graph TD
    A[01-OpenAPI Parser Agent] --> B[02-Solution Architect Agent]
    B --> C[03-Database Layer Agent]
    B --> D[04-Contract Model Agent]
    C --> E[05-Business Layer Agent]
    D --> E
    E --> F[06-API Controller Agent]
    A --> G[07-Authentication Agent]
    B --> G
    G --> F
    F --> H[08-Unit Testing Agent]
    F --> I[09-E2E Testing Agent]
    G --> H
    G --> I
```

## Agent Execution Flow

### Phase 1: Analysis & Design

#### Agent 01: OpenAPI Parser Agent
**[resource "openapi-parser-agent"]** - Parse and validate the OpenAPI specification

**Input**:
```json
{
  "openapi_spec_path": "path/to/openapi.yaml",
  "validation_level": "strict"
}
```

**Tasks**:
1. Parse OpenAPI specification (JSON/YAML)
2. Validate schema compliance
3. Extract all API endpoints with complete details
4. Identify data models and relationships
5. Detect authentication/authorization schemes
6. Generate structured metadata for downstream agents

**Output**: Comprehensive JSON containing:
- API metadata (title, version, description, base path)
- All endpoints with methods, parameters, request/response schemas
- All schemas with properties, validation rules, and relationships
- Security schemes configuration
- Validation errors/warnings

**Success Criteria**:
- ✅ All endpoints parsed correctly
- ✅ All schemas extracted with full properties
- ✅ Relationships between models identified
- ✅ Security schemes properly extracted

---

#### Agent 02: Solution Architect Agent
**[resource "solution-architect-agent"]** - Design the complete solution architecture

**Input**: Output from Agent 01

**Tasks**:
1. Design solution structure with 6 projects:
   - API Controller Project (ASP.NET Core Web API)
   - Business Layer (Class Library)
   - Data Layer (Class Library with EF Core)
   - Contract Models (Class Library for DTOs)
   - Unit Test Project (NUnit)
   - E2E Test Project (Playwright + NUnit)
2. Define project dependencies (no circular references)
3. Specify NuGet packages for each project (.NET 8)
4. Design database schema from OpenAPI models
5. Define repository and service interfaces
6. Create folder structure for each project
7. Define naming conventions

**Output**:
- Complete solution blueprint
- Project details with dependencies and packages
- Database design (tables, relationships, indexes)
- Repository and service interface definitions
- Naming conventions

**Success Criteria**:
- ✅ All 6 projects defined correctly
- ✅ Dependencies form valid DAG (no cycles)
- ✅ NuGet packages are .NET 8 compatible
- ✅ Database schema matches OpenAPI models
- ✅ Architecture follows SOLID principles

---

### Phase 2: Foundation Layer (Parallel Execution)

#### Agent 03: Database Layer Agent
**[resource "database-layer-agent"]** - Create the complete data access layer

**Input**: Output from Agent 01 & Agent 02

**Tasks**:
1. Generate entity models from OpenAPI schemas
2. Create ApplicationDbContext with Fluent API configurations
3. Implement generic IRepository<T> interface
4. Create specific repository interfaces (IProductRepository, etc.)
5. Implement generic Repository<T> class
6. Implement specific repositories with custom queries
7. Create DI registration extension methods
8. Configure entity relationships, constraints, and indexes

**Output**:
- Entity models with navigation properties
- DbContext with all configurations
- Repository interfaces and implementations
- DI registration code
- EF Core migration commands

**Success Criteria**:
- ✅ All entity models created with proper types
- ✅ DbContext configured correctly
- ✅ Repository pattern implemented
- ✅ Async/await used throughout
- ✅ Code compiles without errors

---

#### Agent 04: Contract Model Agent
**[resource "contract-model-agent"]** - Create all DTOs and API contract models

**Input**: Output from Agent 01 & Agent 02

**Tasks**:
1. Generate request DTOs from OpenAPI request bodies
2. Generate response DTOs from OpenAPI responses
3. Create validation attributes based on schema constraints
4. Generate enums from OpenAPI enum definitions
5. Create base classes (BaseResponse, PagedResponse, ErrorResponse)
6. Add XML documentation from OpenAPI descriptions
7. Use record types for immutable DTOs where appropriate

**Output**:
- Request models (CreateEntityRequest, UpdateEntityRequest)
- Response models (EntityResponse, PaginatedResponse, ErrorResponse)
- DTOs for nested objects
- Enum definitions
- Base classes for common patterns

**Success Criteria**:
- ✅ All request/response models generated
- ✅ Validation attributes applied correctly
- ✅ Models match OpenAPI specification exactly
- ✅ Nullable reference types used properly
- ✅ Code compiles without errors

---

### Phase 3: Business Logic Layer

#### Agent 05: Business Layer Agent
**[resource "business-layer-agent"]** - Implement business logic and service layer

**Input**: Outputs from Agents 01, 02, 03, and 04

**Tasks**:
1. Create service interfaces (IProductService, IOrderService, etc.)
2. Implement service classes with business logic
3. Create AutoMapper profiles for entity-DTO mapping
4. Implement FluentValidation validators for request DTOs
5. Create custom exceptions (EntityNotFoundException, etc.)
6. Implement error handling and logging
7. Create DI registration extension methods

**Output**:
- Service interfaces with all CRUD methods
- Service implementations
- AutoMapper mapping profiles
- FluentValidation validators
- Custom exception classes
- DI registration code

**Success Criteria**:
- ✅ All service interfaces and implementations complete
- ✅ AutoMapper profiles configured
- ✅ FluentValidation validators created
- ✅ Error handling implemented
- ✅ Async/await used throughout
- ✅ SOLID principles followed

---

### Phase 4: API Layer

#### Agent 06: API Controller Agent
**[resource "api-controller-agent"]** - Create API controllers with all endpoints

**Input**: Outputs from Agents 01, 02, 04, and 05

**Tasks**:
1. Create controller classes for each resource
2. Implement all CRUD endpoints from OpenAPI spec
3. Add authorization attributes ([Authorize])
4. Configure routing and HTTP method attributes
5. Add Swagger/OpenAPI documentation attributes
6. Create validation and exception filters
7. Create error handling middleware
8. Create Program.cs with complete configuration
9. Create appsettings.json with configuration

**Output**:
- API controllers with all endpoints
- BaseApiController for common functionality
- Validation and exception filters
- Error handling middleware
- Program.cs with DI and middleware configuration
- appsettings.json

**Success Criteria**:
- ✅ All OpenAPI endpoints implemented
- ✅ Controllers follow RESTful conventions
- ✅ Swagger annotations complete
- ✅ Error handling implemented
- ✅ Authorization configured
- ✅ API matches OpenAPI specification

---

#### Agent 07: Authentication Agent
**[resource "authentication-agent"]** - Implement JWT authentication and authorization

**Input**: Outputs from Agents 01 and 02

**Tasks**:
1. Create User and Role entities
2. Add User/Role repositories
3. Create authentication DTOs (LoginRequest, RegisterRequest, AuthResponse)
4. Implement TokenService for JWT generation
5. Implement AuthService (Login, Register, RefreshToken)
6. Create AuthController with authentication endpoints
7. Configure JWT authentication in Program.cs
8. Implement password hashing (BCrypt)
9. Create authorization policies
10. Update appsettings.json with JWT settings

**Output**:
- User and Role entity models
- Authentication DTOs
- TokenService and AuthService
- AuthController
- JWT middleware and configuration
- Password hashing implementation
- JWT settings in appsettings.json

**Success Criteria**:
- ✅ JWT token generation working
- ✅ Authentication endpoints implemented
- ✅ Password hashing configured (never plain text)
- ✅ Authorization policies defined
- ✅ Follows OWASP security best practices

---

### Phase 5: Testing

#### Agent 08: Unit Testing Agent
**[resource "unit-testing-agent"]** - Create comprehensive unit tests

**Input**: Outputs from all previous agents

**Tasks**:
1. Create controller unit tests (mock services)
2. Create service unit tests (mock repositories)
3. Create repository unit tests (in-memory database)
4. Create test fixtures and setup classes
5. Create test data builders
6. Use Moq for mocking dependencies
7. Use FluentAssertions for readable assertions
8. Test both success and error scenarios

**Output**:
- Controller test classes
- Service test classes
- Repository test classes
- Test fixtures and builders
- Mock helpers
- Test coverage > 80%

**Success Criteria**:
- ✅ All layers have unit tests
- ✅ Tests follow AAA pattern (Arrange-Act-Assert)
- ✅ Mocks configured correctly
- ✅ All tests pass
- ✅ Code coverage > 80%

---

#### Agent 09: E2E Testing Agent
**[resource "e2e-testing-agent"]** - Create end-to-end API tests using Playwright

**Input**: Outputs from all previous agents

**Tasks**:
1. Create authentication workflow tests
2. Create CRUD workflow tests for each resource
3. Create business scenario tests
4. Implement ApiClient helper using Playwright
5. Create test fixtures for API setup
6. Create test data helpers
7. Validate response schemas and status codes
8. Test error handling

**Output**:
- E2E authentication tests
- E2E CRUD tests for all resources
- Business workflow tests
- ApiClient helper class
- Test fixtures and data helpers
- Configuration for test environment

**Success Criteria**:
- ✅ Authentication workflow tested
- ✅ All CRUD operations tested
- ✅ Business workflows tested
- ✅ Error scenarios tested
- ✅ Tests are independent and repeatable
- ✅ All tests pass against running API

---

## Execution Instructions

### Prerequisites
- .NET 8 SDK installed
- SQL Server instance available
- Visual Studio 2022 or VS Code
- Node.js (for some tooling)

### Step-by-Step Execution

#### Step 1: Prepare OpenAPI Specification
```bash
# Ensure your OpenAPI spec is ready
# Location: ./sample-openapi.yaml or ./sample-openapi.json
```

#### Step 2: Execute Agent 01 (OpenAPI Parser)
```bash
# Invoke the OpenAPI Parser Agent with your specification
# Input: ./sample-openapi.yaml
# Output: ./output/01-parsed-metadata.json
```

#### Step 3: Execute Agent 02 (Solution Architect)
```bash
# Invoke the Solution Architect Agent
# Input: ./output/01-parsed-metadata.json
# Additional Input: project_name, namespace_prefix
# Output: ./output/02-solution-architecture.json
```

#### Step 4: Execute Agents 03 & 04 in Parallel (Data & Contract Layers)
```bash
# Invoke Database Layer Agent
# Input: ./output/01-parsed-metadata.json + ./output/02-solution-architecture.json
# Output: ./output/03-database-layer-files.json

# Invoke Contract Model Agent (parallel)
# Input: ./output/01-parsed-metadata.json + ./output/02-solution-architecture.json
# Output: ./output/04-contract-models-files.json
```

#### Step 5: Execute Agent 05 (Business Layer)
```bash
# Invoke Business Layer Agent
# Input: Outputs from 01, 02, 03, 04
# Output: ./output/05-business-layer-files.json
```

#### Step 6: Execute Agents 06 & 07 in Parallel (API & Auth)
```bash
# Invoke API Controller Agent
# Input: Outputs from 01, 02, 04, 05
# Output: ./output/06-api-controller-files.json

# Invoke Authentication Agent (parallel)
# Input: Outputs from 01, 02
# Output: ./output/07-authentication-files.json
```

#### Step 7: Create Solution and Projects
```bash
# Create the solution directory
mkdir MyWebApi
cd MyWebApi

# Create solution file
dotnet new sln -n MyWebApi

# Create projects based on architecture blueprint
dotnet new webapi -n MyWebApi.Api -f net8.0
dotnet new classlib -n MyWebApi.BusinessLayer -f net8.0
dotnet new classlib -n MyWebApi.DataLayer -f net8.0
dotnet new classlib -n MyWebApi.ContractModels -f net8.0
dotnet new nunit -n MyWebApi.UnitTests -f net8.0
dotnet new nunit -n MyWebApi.E2ETests -f net8.0

# Add projects to solution
dotnet sln add MyWebApi.Api/MyWebApi.Api.csproj
dotnet sln add MyWebApi.BusinessLayer/MyWebApi.BusinessLayer.csproj
dotnet sln add MyWebApi.DataLayer/MyWebApi.DataLayer.csproj
dotnet sln add MyWebApi.ContractModels/MyWebApi.ContractModels.csproj
dotnet sln add MyWebApi.UnitTests/MyWebApi.UnitTests.csproj
dotnet sln add MyWebApi.E2ETests/MyWebApi.E2ETests.csproj

# Add project references
dotnet add MyWebApi.Api/MyWebApi.Api.csproj reference MyWebApi.BusinessLayer/MyWebApi.BusinessLayer.csproj
dotnet add MyWebApi.Api/MyWebApi.Api.csproj reference MyWebApi.ContractModels/MyWebApi.ContractModels.csproj
dotnet add MyWebApi.BusinessLayer/MyWebApi.BusinessLayer.csproj reference MyWebApi.DataLayer/MyWebApi.DataLayer.csproj
dotnet add MyWebApi.BusinessLayer/MyWebApi.BusinessLayer.csproj reference MyWebApi.ContractModels/MyWebApi.ContractModels.csproj
dotnet add MyWebApi.UnitTests/MyWebApi.UnitTests.csproj reference MyWebApi.Api/MyWebApi.Api.csproj
dotnet add MyWebApi.UnitTests/MyWebApi.UnitTests.csproj reference MyWebApi.BusinessLayer/MyWebApi.BusinessLayer.csproj
dotnet add MyWebApi.UnitTests/MyWebApi.UnitTests.csproj reference MyWebApi.DataLayer/MyWebApi.DataLayer.csproj
```

#### Step 8: Install NuGet Packages
```bash
# API Project
cd MyWebApi.Api
dotnet add package Microsoft.AspNetCore.Authentication.JwtBearer
dotnet add package Swashbuckle.AspNetCore
dotnet add package Serilog.AspNetCore

# Business Layer
cd ../MyWebApi.BusinessLayer
dotnet add package AutoMapper
dotnet add package AutoMapper.Extensions.Microsoft.DependencyInjection
dotnet add package FluentValidation
dotnet add package FluentValidation.DependencyInjectionExtensions

# Data Layer
cd ../MyWebApi.DataLayer
dotnet add package Microsoft.EntityFrameworkCore.SqlServer
dotnet add package Microsoft.EntityFrameworkCore.Tools
dotnet add package Microsoft.EntityFrameworkCore.Design

# Unit Tests
cd ../MyWebApi.UnitTests
dotnet add package NUnit
dotnet add package NUnit3TestAdapter
dotnet add package Moq
dotnet add package FluentAssertions
dotnet add package Microsoft.EntityFrameworkCore.InMemory

# E2E Tests
cd ../MyWebApi.E2ETests
dotnet add package NUnit
dotnet add package NUnit3TestAdapter
dotnet add package Microsoft.Playwright
dotnet add package FluentAssertions
```

#### Step 9: Copy Generated Code Files
```bash
# Copy files from agent outputs to respective project folders
# Use the file paths specified in each agent's output
```

#### Step 10: Execute Agents 08 & 09 (Testing)
```bash
# Invoke Unit Testing Agent
# Input: All previous outputs
# Output: ./output/08-unit-test-files.json

# Invoke E2E Testing Agent
# Input: All previous outputs
# Output: ./output/09-e2e-test-files.json
```

#### Step 11: Configure Database
```bash
# Update connection string in appsettings.json
# Example:
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=localhost;Database=MyWebApiDb;Trusted_Connection=True;TrustServerCertificate=True;"
  },
  "JwtSettings": {
    "SecretKey": "your-secret-key-min-32-characters-long-change-in-production",
    "Issuer": "MyWebApi",
    "Audience": "MyWebApiClients",
    "ExpirationMinutes": 60
  }
}

# Run EF Core migrations
cd MyWebApi.Api
dotnet ef migrations add InitialCreate --project ../MyWebApi.DataLayer
dotnet ef database update
```

#### Step 12: Build and Run
```bash
# Build the entire solution
dotnet build

# Run the API
cd MyWebApi.Api
dotnet run
```

#### Step 13: Run Tests
```bash
# Run unit tests
cd ../MyWebApi.UnitTests
dotnet test

# Run E2E tests (ensure API is running)
cd ../MyWebApi.E2ETests
dotnet test
```

#### Step 14: Access Swagger UI
```
Open browser: https://localhost:5001/swagger
```

---

## Agent Communication Protocol

### Data Flow Between Agents

```json
{
  "agent_01_output": {
    "api_metadata": {},
    "endpoints": [],
    "schemas": [],
    "security_schemes": {},
    "validation_errors": []
  },
  "agent_02_input": "agent_01_output + { project_name, namespace_prefix }",
  "agent_02_output": {
    "solution_structure": {},
    "database_design": {},
    "repository_interfaces": [],
    "service_interfaces": []
  },
  "agent_03_input": "agent_01_output + agent_02_output",
  "agent_04_input": "agent_01_output + agent_02_output",
  "agent_05_input": "agent_01_output + agent_02_output + agent_03_output + agent_04_output",
  "agent_06_input": "agent_01_output + agent_02_output + agent_04_output + agent_05_output",
  "agent_07_input": "agent_01_output + agent_02_output",
  "agent_08_input": "all_previous_outputs",
  "agent_09_input": "all_previous_outputs"
}
```

---

## Quality Checks

### After Each Agent
1. Validate output JSON schema
2. Check for missing required fields
3. Verify no null/undefined values in critical paths
4. Log warnings and errors

### After Phase Completion
1. **Phase 1**: Ensure all OpenAPI endpoints and schemas captured
2. **Phase 2**: Verify no circular dependencies, all packages valid
3. **Phase 3**: Check entity relationships, repository interfaces complete
4. **Phase 4**: Verify code compiles, all endpoints implemented
5. **Phase 5**: Ensure test coverage > 80%, all tests pass

---

## Troubleshooting

### Common Issues

#### Agent 01: OpenAPI Parser
- **Issue**: Invalid OpenAPI spec
- **Solution**: Validate spec using online validators (swagger.io)

#### Agent 02: Solution Architect
- **Issue**: Circular dependencies detected
- **Solution**: Review project reference design, ensure layered architecture

#### Agent 03: Database Layer
- **Issue**: EF Core migration errors
- **Solution**: Check entity configurations, relationship mappings

#### Agent 04: Contract Models
- **Issue**: Missing validation attributes
- **Solution**: Review OpenAPI schema constraints

#### Agent 05: Business Layer
- **Issue**: AutoMapper mapping errors
- **Solution**: Verify DTO and entity property names match

#### Agent 06: API Controller
- **Issue**: Route conflicts
- **Solution**: Review route templates, ensure uniqueness

#### Agent 07: Authentication
- **Issue**: JWT token validation fails
- **Solution**: Check secret key length (min 32 chars), issuer/audience match

#### Agent 08: Unit Testing
- **Issue**: Mock setup errors
- **Solution**: Verify interface signatures, use It.IsAny<T>() for flexible matching

#### Agent 09: E2E Testing
- **Issue**: Tests fail to connect to API
- **Solution**: Ensure API is running, check base URL in config

---

## Technical Stack Summary

- **Framework**: .NET 8
- **Database**: SQL Server
- **ORM**: Entity Framework Core 8
- **Patterns**: Repository Pattern, Service Layer, DTO Pattern
- **DI**: Built-in .NET Dependency Injection
- **Authentication**: JWT Bearer Tokens
- **Validation**: FluentValidation + Data Annotations
- **Mapping**: AutoMapper
- **API Documentation**: Swagger/OpenAPI
- **Unit Testing**: NUnit + Moq + FluentAssertions
- **E2E Testing**: Microsoft Playwright + NUnit
- **Logging**: Serilog (recommended)

---

## Key Principles

1. **SOLID Principles**: All code follows SOLID design principles
2. **Clean Architecture**: Clear separation of concerns across layers
3. **Dependency Inversion**: High-level modules don't depend on low-level modules
4. **Testability**: All components are testable with dependency injection
5. **Security First**: JWT authentication, password hashing, OWASP guidelines
6. **Async/Await**: All I/O operations are asynchronous
7. **Error Handling**: Comprehensive exception handling throughout
8. **Documentation**: XML comments, Swagger docs, clear naming

---

## Output Structure

```
MyWebApi/
├── MyWebApi.sln
├── MyWebApi.Api/
│   ├── Controllers/
│   ├── Filters/
│   ├── Middlewares/
│   ├── Program.cs
│   └── appsettings.json
├── MyWebApi.BusinessLayer/
│   ├── Interfaces/
│   ├── Services/
│   ├── Mappings/
│   ├── Validators/
│   ├── Exceptions/
│   └── Extensions/
├── MyWebApi.DataLayer/
│   ├── Models/
│   ├── Context/
│   ├── Repositories/
│   │   └── Interfaces/
│   └── Extensions/
├── MyWebApi.ContractModels/
│   ├── Requests/
│   ├── Responses/
│   ├── DTOs/
│   ├── Enums/
│   └── Common/
├── MyWebApi.UnitTests/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   ├── Fixtures/
│   └── Builders/
└── MyWebApi.E2ETests/
    ├── Tests/
    ├── Fixtures/
    ├── Helpers/
    └── appsettings.Test.json
```

---

## Next Steps

After successful generation:

1. **Review Generated Code**: Manually review all generated files
2. **Customize Business Logic**: Add specific business rules
3. **Configure Database**: Set up connection strings for environments
4. **Security Review**: Review JWT configuration, password policies
5. **Performance Tuning**: Add caching, optimize queries
6. **Deployment**: Configure CI/CD pipelines
7. **Monitoring**: Add Application Insights or similar
8. **Documentation**: Create API documentation for consumers

---

## Support

For issues or questions about specific agents, refer to:
- [resource "openapi-parser-agent"]
- [resource "solution-architect-agent"]
- [resource "database-layer-agent"]
- [resource "contract-model-agent"]
- [resource "business-layer-agent"]
- [resource "api-controller-agent"]
- [resource "authentication-agent"]
- [resource "unit-testing-agent"]
- [resource "e2e-testing-agent"]

--- 

## Version

**Version**: 1.0
**Last Updated**: 2025-12-06
**Compatible with**: .NET 8, OpenAPI 3.0+
