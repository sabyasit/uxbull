import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable({
    providedIn: 'root'
})
export class LoaderService {
    private loadingSubject = new BehaviorSubject<boolean>(false);
    public isLoading$: Observable<boolean> = this.loadingSubject.asObservable();

    constructor(private snackBar: MatSnackBar) { }

    // Loader methods
    show(): void {
        this.loadingSubject.next(true);
    }

    hide(): void {
        this.loadingSubject.next(false);
    }

    // Toaster methods
    showError(message: string, duration: number = 5000): void {
        const config: MatSnackBarConfig = {
            duration,
            horizontalPosition: 'center',
            verticalPosition: 'bottom',
            panelClass: ['error-snackbar']
        };
        this.snackBar.open(message, '', config);
    }

    showSuccess(message: string, duration: number = 3000): void {
        const config: MatSnackBarConfig = {
            duration,
            horizontalPosition: 'center',
            verticalPosition: 'bottom',
            panelClass: ['success-snackbar']
        };
        this.snackBar.open(message, 'Close', config);
    }

    showInfo(message: string, duration: number = 3000): void {
        const config: MatSnackBarConfig = {
            duration,
            horizontalPosition: 'center',
            verticalPosition: 'bottom',
            panelClass: ['info-snackbar']
        };
        this.snackBar.open(message, 'Close', config);
    }

    hideToaster(): void {
        this.snackBar.dismiss();
    }
}
