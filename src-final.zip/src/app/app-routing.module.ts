import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { UploadComponent } from './upload/upload.component';
import { ValidatorComponent } from './validator/validator.component';
import { EditorComponent } from './editor/editor.component';
import { PreviewComponent } from './preview/preview.component';
import { TemplatesComponent } from './templates/templates.component';

const routes: Routes = [
  { path: 'upload', component: UploadComponent },
  { path: 'validation', component: ValidatorComponent },
  { path: 'editor', component: EditorComponent },
  { path: 'preview', component: PreviewComponent },
  { path: 'templates', component: TemplatesComponent },
  { path: '', redirectTo: '/upload', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
