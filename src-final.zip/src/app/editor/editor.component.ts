import { Component } from '@angular/core';
import { Router } from '@angular/router';

interface PersonalInfo {
    fullName: string;
    jobTitle: string;
    phone: string;
    email: string;
}

interface WorkExperience {
    title: string;
    company: string;
    description: string;
    startDate?: string;
    endDate?: string;
}

interface Template {
    id: string;
    name: string;
    isActive: boolean;
}

@Component({
    selector: 'app-editor',
    templateUrl: './editor.component.html',
    styleUrls: ['./editor.component.css']
})
export class EditorComponent {
    // Personal Information
    personalInfo: PersonalInfo = {
        fullName: 'Alex Morgan',
        jobTitle: 'Senior Product Designer',
        phone: '+1 (555) 000-1234',
        email: 'alex.morgan@example.com'
    };

    // Professional Summary
    professionalSummary = 'Experienced Product Designer with over 8 years of experience in building user-centric digital products. Proven track record of improving user engagement and streamlining workflows.';
    summaryCharCount = 180;
    summaryMaxLength = 500;

    // Work Experience
    workExperiences: WorkExperience[] = [
        {
            title: 'Senior Designer',
            company: 'TechFlow Inc.',
            description: ''
        }
    ];

    // Skills
    skills: string[] = ['Figma', 'React', 'Tailwind CSS'];
    newSkill = '';

    // Templates
    templates: Template[] = [
        { id: 'modern-blue', name: 'Modern Blue', isActive: true },
        { id: 'minimalist', name: 'Minimalist', isActive: false },
        { id: 'sidebar', name: 'Sidebar', isActive: false },
        { id: 'classic', name: 'Classic', isActive: false }
    ];

    selectedTemplate: Template = this.templates[0];

    // Accordion states
    personalInfoExpanded = true;
    summaryExpanded = false;
    experienceExpanded = true;
    skillsExpanded = false;

    constructor(private router: Router) { }

    // Character count update
    updateSummaryCount(): void {
        this.summaryCharCount = this.professionalSummary.length;
    }

    // Add new skill
    addSkill(): void {
        if (this.newSkill.trim() && !this.skills.includes(this.newSkill.trim())) {
            this.skills.push(this.newSkill.trim());
            this.newSkill = '';
        }
    }

    // Remove skill
    removeSkill(index: number): void {
        this.skills.splice(index, 1);
    }

    // Add work experience
    addWorkExperience(): void {
        this.workExperiences.push({
            title: '',
            company: '',
            description: ''
        });
    }

    // Remove work experience
    removeWorkExperience(index: number): void {
        this.workExperiences.splice(index, 1);
    }

    // Select template
    selectTemplate(template: Template): void {
        this.templates.forEach(t => t.isActive = false);
        template.isActive = true;
        this.selectedTemplate = template;
    }

    next() {
        this.router.navigate(['/preview']);
    }
}
