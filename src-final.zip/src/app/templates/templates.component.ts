import { Component } from '@angular/core';
import { Router } from '@angular/router';

interface Template {
    id: string;
    name: string;
    description: string;
    category: string;
    previewImage: string;
    useTemplate: boolean;
}

@Component({
    selector: 'app-templates',
    templateUrl: './templates.component.html',
    styleUrls: ['./templates.component.css']
})
export class TemplatesComponent {
    selectedCategory = 'all';

    categories = [
        { id: 'all', name: 'All Templates' },
        { id: 'modern', name: 'Modern' },
        { id: 'professional', name: 'Professional' },
        { id: 'creative', name: 'Creative' },
        { id: 'minimal', name: 'Minimal' }
    ];

    templates: Template[] = [
        {
            id: '1',
            name: 'LTIMindtree',
            description: 'LTIMindtree official template.',
            category: 'professional',
            previewImage: '',
            useTemplate: false
        },
        {
            id: '2',
            name: 'LTIMindtree',
            description: 'LTIMindtree official template.',
            category: 'professional',
            previewImage: '',
            useTemplate: false
        }
    ];

    get filteredTemplates(): Template[] {
        if (this.selectedCategory === 'all') {
            return this.templates;
        }
        return this.templates.filter(t => t.category === this.selectedCategory);
    }

    constructor(private router: Router) { }

    selectCategory(categoryId: string): void {
        this.selectedCategory = categoryId;
    }

    useTemplate(template: Template): void {
        this.templates.forEach(t => t.useTemplate = false);
        template.useTemplate = true;
    }

    previewTemplate(template: Template): void {
        console.log('Previewing template:', template.id);
        // TODO: Show template preview
    }

    next() {
        this.router.navigate(['/editor']);
    }
}
