import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.css']
})
export class StepperComponent implements OnInit {
  steps = [
    { label: 'Upload Resume', route: '/upload', number: 1 },
    { label: 'Validate Resume', route: '/validation', number: 2 },
    { label: 'Choose Template', route: '/templates', number: 3 },
    { label: 'Edit Resume', route: '/editor', number: 4 },
    { label: 'Preview', route: '/preview', number: 5 }
  ];

  currentStep = 1;

  constructor(private router: Router) { }

  ngOnInit() {
    // Initialize current step based on current URL
    this.updateCurrentStep(this.router.url);

    // Subscribe to router events to update step on navigation
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.updateCurrentStep(event.urlAfterRedirects || event.url);
    });
  }

  updateCurrentStep(url: string) {
    if (url.includes('upload')) this.currentStep = 1;
    else if (url.includes('validation')) this.currentStep = 2;
    else if (url.includes('templates')) this.currentStep = 3;
    else if (url.includes('editor')) this.currentStep = 4;
    else if (url.includes('preview')) this.currentStep = 5;
  }
}
