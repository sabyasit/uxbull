import { Component } from '@angular/core';

interface CVTemplate {
    id: string;
    name: string;
    isActive: boolean;
}

@Component({
    selector: 'app-preview',
    templateUrl: './preview.component.html',
    styleUrls: ['./preview.component.css']
})
export class PreviewComponent {
    // Templates
    templates: CVTemplate[] = [
        { id: 'minimal', name: 'Minimal', isActive: true },
        { id: 'sidebar', name: 'Sidebar', isActive: false },
        { id: 'modern', name: 'Modern', isActive: false }
    ];

    selectedTemplate: CVTemplate = this.templates[0];

    // CV Data (mock data)
    cv = {
        name: 'Sarah Jenkins',
        jobTitle: 'Senior Product Designer',
        email: 'sarah.jenkins@example.com',
        phone: '+1 (555) 123-4567',
        location: 'San Francisco, CA',
        profile: 'Creative and detail-oriented Product Designer with 6+ years of experience building digital products for SaaS platforms. Expert in UI systems and user-centric design methodology.',
        experience: [
            {
                title: 'Senior Product Designer',
                company: 'TechFlow Inc.',
                period: '2021 - Present',
                achievements: [
                    'Led the redesign of the core analytics dashboard, increasing user engagement by 40%.',
                    'Established and maintained the corporate design system "FlowUI" used by 20+ developers.',
                    'Mentored junior designers and conducted bi-weekly design critiques.'
                ]
            },
            {
                title: 'UX Designer',
                company: 'Creative Solutions Agency',
                period: '2018 - 2021',
                achievements: [
                    'Designed mobile-first interfaces for fintech clients.',
                    'Collaborated with PMs to define MVP features for startup clients.',
                    'Conducted A/B testing on landing pages, improving conversion rates by 15%.'
                ]
            }
        ],
        education: [
            {
                degree: 'MSc Human-Computer Interaction',
                school: 'Stanford University',
                period: '2016-2018'
            },
            {
                degree: 'BFA Graphic Design',
                school: 'RISD',
                period: '2012-2016'
            }
        ],
        skills: ['Figma', 'Prototyping', 'HTML/CSS', 'User Research', 'Design Systems', 'Agile'],
        certifications: [
            { name: 'Google UX Certificate', year: '2022' },
            { name: 'CSM Scrum Master', year: '2020' }
        ]
    };

    // Select template
    selectTemplate(template: CVTemplate): void {
        this.templates.forEach(t => t.isActive = false);
        template.isActive = true;
        this.selectedTemplate = template;
    }

    // Actions
    printCV(): void {
        window.print();
    }

    downloadPDF(): void {
        console.log('Download PDF');
        // TODO: Implement PDF download
    }

    editDetails(): void {
        console.log('Edit details');
        // TODO: Navigate to editor
    }

    seeAllTemplates(): void {
        console.log('See all templates');
        // TODO: Navigate to templates page
    }
}
