import { Component } from '@angular/core';
import { Router } from '@angular/router';

interface ValidationCard {
    title: string;
    description: string;
    status: 'success' | 'warning' | 'error';
    isExpanded?: boolean;
    details?: ValidationDetail[];
}

interface ValidationDetail {
    icon: string;
    title: string;
    description: string;
    actionLabel: string;
}

@Component({
    selector: 'app-validator',
    templateUrl: './validator.component.html',
    styleUrls: ['./validator.component.css']
})
export class ValidatorComponent {
    healthScore = 50;

    constructor(private router: Router) { }

    validationCards: ValidationCard[] = [
        {
            title: 'Personal Details',
            description: 'All mandatory contact info is present.',
            status: 'success',
            isExpanded: false
        },
        {
            title: 'Work History',
            description: 'Found 2 suggestions for improvement.',
            status: 'warning',
            isExpanded: true,
            details: [
                {
                    icon: 'lightbulb',
                    title: 'Role Description Length',
                    description: 'The description for <strong>Product Manager at TechCorp</strong> is too short (under 50 words). Aim for at least 3 bullet points detailing your achievements.',
                    actionLabel: 'Edit Role'
                },
                {
                    icon: 'lightbulb',
                    title: 'Missing Metrics',
                    description: 'Try to quantify your impact in your <strong>Senior Designer</strong> role. Using numbers (e.g., "Increased conversion by 20%") makes your CV stronger.',
                    actionLabel: 'Add Metrics'
                }
            ]
        },
        {
            title: 'Education',
            description: 'Degrees and institutions are clear.',
            status: 'success',
            isExpanded: false
        },
        {
            title: 'Skills',
            description: '12 skills listed, relevant to your role.',
            status: 'success',
            isExpanded: false
        }
    ];

    toggleCard(card: ValidationCard): void {
        card.isExpanded = !card.isExpanded;
    }

    onActionClick(detail: ValidationDetail): void {
        console.log('Action clicked:', detail.actionLabel);
        // TODO: Implement action logic
    }

    next(): void {
        this.router.navigate(['/templates']);
    }
}
