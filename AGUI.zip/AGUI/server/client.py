from agent_framework_ollama import OllamaChatClient
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from copilotkit.integrations.fastapi import add_fastapi_endpoint
from copilotkit import CopilotKitRemoteEndpoint, Action
from typing import Annotated
from agent import create_agent
from fastapi.middleware.cors import CORSMiddleware

client = OllamaChatClient(
    host="http://localhost:11434",
    model="gemma4:e2b",
    additional_properties={
        "think": False
    }
)

agent = create_agent(client)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=False,  # Must be False if allow_origins=["*"]
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# 1. Define your backend actions/logic
def sample_action(name: str):
    return f"Hello, {name}!"

sdk = CopilotKitRemoteEndpoint(
    agents=[agent]
)

# 2. Add the CopilotKit endpoint (this acts as your runtime URL)
add_fastapi_endpoint(app, sdk, "/copilotkit")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)