from typing import Annotated
from agent_framework.ollama import OllamaChatClient
from agent_framework import Agent, tool
from agent_framework_ag_ui import add_agent_framework_fastapi_endpoint
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import Field
from agent import create_agent


client = OllamaChatClient(
    host="http://localhost:11434",
    model="gemma4:e2b",
    additional_properties={
        "think": False
    }
)

agent = create_agent(client)
    
app = FastAPI(title="AG-UI Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows all origins
    allow_credentials=False,  # Must be False if allow_origins=["*"]
    allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
    allow_headers=["*"],  # Allows all headers
)

# Register the AG-UI endpoint
add_agent_framework_fastapi_endpoint(app, agent, "/")

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8888)