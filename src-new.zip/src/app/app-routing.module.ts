import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StepOneComponent } from './components/steps/step-one/step-one.component';
import { StepTwoComponent } from './components/steps/step-two/step-two.component';
import { StepThreeComponent } from './components/steps/step-three/step-three.component';
import { StepFourComponent } from './components/steps/step-four/step-four.component';

const routes: Routes = [
  { path: '', redirectTo: '/step-1', pathMatch: 'full' },
  { path: 'step-1', component: StepOneComponent },
  { path: 'step-2', component: StepTwoComponent },
  { path: 'step-3', component: StepThreeComponent },
  { path: 'step-4', component: StepFourComponent },
  { path: '**', redirectTo: '/step-1' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
