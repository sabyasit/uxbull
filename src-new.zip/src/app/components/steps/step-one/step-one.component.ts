import { Component } from '@angular/core';
import { LoaderService } from '../../../services/loader.service';

@Component({
  selector: 'app-step-one',
  templateUrl: './step-one.component.html',
  styleUrls: ['./step-one.component.scss']
})
export class StepOneComponent {

  isDragging = false;
  isUploaded = false;
  uploadedFileName: string | null = null;
  errorMessage: string | null = null;

  constructor(private loaderService: LoaderService) { }

  onDragOver(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = true;
  }

  onDragLeave(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
  }

  onDrop(event: DragEvent) {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging = false;
    const files = event.dataTransfer?.files;
    if (files && files.length > 0) {
      this.handleFile(files[0]);
    }
  }

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.handleFile(file);
    }
  }

  handleFile(file: File) {
    this.errorMessage = null;
    if (file.type !== 'application/pdf') {
      this.errorMessage = 'Please upload a valid PDF file.';
      return;
    }

    this.simulateUpload(file);
  }

  simulateUpload(file: File) {
    this.loaderService.show();
    // Simulate upload delay
    setTimeout(() => {
      this.uploadedFileName = file.name;
      this.isUploaded = true;
      this.loaderService.hide();
    }, 2000);
  }
}
