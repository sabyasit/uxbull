import { Component } from '@angular/core';

interface PersonalInfo {
  name: string;
  role: string;
  email: string;
  phone: string;
  location: string;
}

interface ExperienceItem {
  role: string;
  company: string;
  period: string;
  description: string;
}

interface EducationItem {
  degree: string;
  school: string;
  period: string;
}

interface ResumeSection {
  id: string;
  title: string;
  visible: boolean;
  content?: string;
  items?: any[]; // Using any[] here to simplify template iteration given the union type complexity, or could use specific union types
}

@Component({
  selector: 'app-step-three',
  templateUrl: './step-three.component.html',
  styleUrls: ['./step-three.component.scss']
})
export class StepThreeComponent {

  selectedTemplate = 'modern';

  resumeData: { personal: PersonalInfo; sections: ResumeSection[] } = {
    personal: {
      name: 'John Doe',
      role: 'Senior UX Designer',
      email: 'john.doe@example.com',
      phone: '+1 (555) 123-4567',
      location: 'San Francisco, CA'
    },
    sections: [
      {
        id: 'summary',
        title: 'Professional Summary',
        content: 'Experienced UX Designer with a track record of creating user-centric digital products. Skilled in wireframing, prototyping, and user research. Passionate about creating intuitive and accessible interfaces.',
        visible: true
      },
      {
        id: 'experience',
        title: 'Experience',
        items: [
          {
            role: 'Lead Designer',
            company: 'Tech Solutions Inc.',
            period: '2020 - Present',
            description: 'Leading a team of designers to revamp the core product suite. Improved user engagement by 40%.'
          },
          {
            role: 'UX Designer',
            company: 'Creative Agency',
            period: '2018 - 2020',
            description: 'Designed web and mobile interfaces for various clients. Conducted usability testing and iterative improvements.'
          }
        ],
        visible: true
      },
      {
        id: 'education',
        title: 'Education',
        items: [
          {
            degree: 'Bachelor of Fine Arts in Design',
            school: 'University of Arts',
            period: '2014 - 2018'
          }
        ],
        visible: true
      },
      {
        id: 'skills',
        title: 'Skills',
        items: ['Figma', 'Adobe XD', 'Sketch', 'HTML/CSS', 'User Research', 'Prototyping'],
        visible: true
      }
    ]
  };

  toggleSection(section: ResumeSection) {
    section.visible = !section.visible;
  }
}
