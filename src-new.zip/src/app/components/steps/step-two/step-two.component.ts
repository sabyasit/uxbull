import { Component } from '@angular/core';
import { LoaderService } from '../../../services/loader.service';

interface IValidationResult {
  section: string;
  status: 'success' | 'warning' | 'error';
  message: string;
}

@Component({
  selector: 'app-step-two',
  templateUrl: './step-two.component.html',
  styleUrls: ['./step-two.component.scss']
})
export class StepTwoComponent {

  isAnalyzing = false;
  analysisComplete = false;
  results: IValidationResult[] = [];

  constructor(private loaderService: LoaderService) { }

  startAnalysis() {
    this.isAnalyzing = true;
    this.analysisComplete = false;
    this.results = [];
    this.loaderService.show();

    setTimeout(() => {
      this.results = [
        {
          section: 'Contact Information',
          status: 'success',
          message: 'All required contact details are present and valid.'
        },
        {
          section: 'Professional Summary',
          status: 'warning',
          message: 'Summary is a bit short. Consider adding more keywords.'
        },
        {
          section: 'Experience',
          status: 'success',
          message: 'Work history is well-structured with clear dates.'
        },
        {
          section: 'Skills',
          status: 'success',
          message: 'Relevant technical skills identified.'
        },
        {
          section: 'Education',
          status: 'warning',
          message: 'Education dates might be missing for some entries.'
        }
      ];

      this.isAnalyzing = false;
      this.analysisComplete = true;
      this.loaderService.hide();
    }, 2500);
  }
}
