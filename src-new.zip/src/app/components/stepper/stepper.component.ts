import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss']
})
export class StepperComponent implements OnInit {
  steps = [
    { label: 'Step 1', route: '/step-1', number: 1 },
    { label: 'Step 2', route: '/step-2', number: 2 },
    { label: 'Step 3', route: '/step-3', number: 3 },
    { label: 'Step 4', route: '/step-4', number: 4 }
  ];

  currentStep = 1;

  constructor(private router: Router) { }

  ngOnInit() {
    // Initialize current step based on current URL
    this.updateCurrentStep(this.router.url);

    // Subscribe to router events to update step on navigation
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: any) => {
      this.updateCurrentStep(event.urlAfterRedirects || event.url);
    });
  }

  updateCurrentStep(url: string) {
    if (url.includes('step-1')) this.currentStep = 1;
    else if (url.includes('step-2')) this.currentStep = 2;
    else if (url.includes('step-3')) this.currentStep = 3;
    else if (url.includes('step-4')) this.currentStep = 4;
  }
}
