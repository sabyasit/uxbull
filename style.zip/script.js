document.addEventListener('DOMContentLoaded', () => {
    const navItems = document.querySelectorAll('.nav-item');
    const editorPlaceholder = document.getElementById('editor-placeholder');

    // Function to highlight the preview section
    function highlightSection(sectionId) {
        // Remove highlight from all sections
        document.querySelectorAll('.cv-section, .cv-header').forEach(el => {
            el.classList.remove('highlight');
        });

        // Add highlight to target section
        const targetId = `preview-${sectionId}`;
        const targetElement = document.getElementById(targetId);

        if (targetElement) {
            targetElement.classList.add('highlight');
            targetElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }

    // Function to update editor panel content (placeholder)
    function updateEditorPanel(sectionId, sectionName) {
        editorPlaceholder.innerHTML = `
            <h2>Editing: ${sectionName}</h2>
            <p>This is where the inputs for <strong>${sectionName}</strong> will go.</p>
            <div style="margin-top: 1rem; padding: 1rem; border: 1px dashed #ccc; background: #fff;">
                Input form placeholders...
            </div>
        `;
    }

    // Event Listeners for Nav bar
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            // Update active state in nav
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');

            const sectionId = item.dataset.section;
            const sectionName = item.innerText.trim();

            highlightSection(sectionId);
            updateEditorPanel(sectionId, sectionName);
        });
    });

    // Initial load state
    const firstItem = navItems[0];
    if (firstItem) {
        firstItem.click();
    }
});
