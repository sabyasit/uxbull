# ASP.NET Web API Best Practices Agent

## Overview
This agent serves as a comprehensive guide for building production-ready ASP.NET Web APIs using .NET 8+. It provides actionable best practices, code examples, and architectural patterns to ensure your APIs are secure, performant, maintainable, and follow industry standards.

---

## Table of Contents
1. [RESTful API Design](#1-restful-api-design)
2. [Project Structure](#2-project-structure)
3. [Controllers & Routing](#3-controllers--routing)
4. [Dependency Injection](#4-dependency-injection)
5. [Data Access & Entity Framework](#5-data-access--entity-framework)
6. [Authentication & Security](#6-authentication--security)
7. [Error Handling & Validation](#7-error-handling--validation)
8. [Async Programming](#8-async-programming)
9. [Performance Optimization](#9-performance-optimization)
10. [Logging & Monitoring](#10-logging--monitoring)
11. [API Documentation](#11-api-documentation)
12. [Testing](#12-testing)

---

## 1. RESTful API Design

### Resource Naming Conventions
```
✅ Good:
GET    /api/products              // Get all products
GET    /api/products/{id}         // Get specific product
POST   /api/products              // Create product
PUT    /api/products/{id}         // Update entire product
PATCH  /api/products/{id}         // Partial update
DELETE /api/products/{id}         // Delete product
GET    /api/orders/{id}/items     // Nested resources

❌ Bad:
GET    /api/getProducts           // Don't use verbs
POST   /api/product/create        // Don't use verbs
GET    /api/Product               // Use lowercase
GET    /api/products-list         // Inconsistent naming
```

### HTTP Status Codes
```csharp
// Success Responses
200 OK              // GET, PUT, PATCH successful
201 Created         // POST successful (include Location header)
204 No Content      // DELETE successful or PUT with no response body
206 Partial Content // Paginated response

// Client Errors
400 Bad Request           // Validation failed, malformed request
401 Unauthorized          // Missing or invalid authentication
403 Forbidden            // Authenticated but lacks permission
404 Not Found            // Resource doesn't exist
405 Method Not Allowed   // HTTP method not supported
409 Conflict            // Resource conflict (e.g., duplicate)
422 Unprocessable Entity // Semantic validation errors
429 Too Many Requests    // Rate limiting

// Server Errors
500 Internal Server Error // Unexpected error
503 Service Unavailable   // Temporary unavailability
```

### API Versioning Strategy
```csharp
// URL Versioning (Recommended for public APIs)
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/products")]
public class ProductsController : ControllerBase { }

// Header Versioning
// Request Header: api-version: 1.0

// Query String Versioning
// GET /api/products?api-version=1.0
```

---

## 2. Project Structure

### Recommended Solution Architecture
```
MyWebApi/
├── MyWebApi.Api/                    # Web API Project
│   ├── Controllers/
│   ├── Middleware/
│   ├── Filters/
│   ├── Program.cs
│   └── appsettings.json
├── MyWebApi.Core/                   # Business Logic
│   ├── Interfaces/
│   ├── Services/
│   ├── DTOs/
│   ├── Validators/
│   └── Exceptions/
├── MyWebApi.Infrastructure/         # Data Access
│   ├── Data/
│   ├── Repositories/
│   └── Configurations/
└── MyWebApi.Tests/                  # Test Project
    ├── Unit/
    ├── Integration/
    └── Helpers/
```

### Separation of Concerns
```csharp
// 🎯 Controller (thin, handles HTTP concerns only)
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _service;
    
    public ProductsController(IProductService service)
        => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var products = await _service.GetAllProductsAsync();
        return Ok(products);
    }
}

// 🎯 Service (business logic)
public class ProductService : IProductService
{
    private readonly IProductRepository _repository;
    private readonly IMapper _mapper;
    
    public async Task<IEnumerable<ProductDto>> GetAllProductsAsync()
    {
        var products = await _repository.GetAllAsync();
        return _mapper.Map<IEnumerable<ProductDto>>(products);
    }
}

// 🎯 Repository (data access)
public class ProductRepository : IProductRepository
{
    private readonly AppDbContext _context;
    
    public async Task<IEnumerable<Product>> GetAllAsync()
        => await _context.Products.AsNoTracking().ToListAsync();
}
```

---

## 3. Controllers & Routing

### Base Controller Pattern
```csharp
[ApiController]
[Route("api/[controller]")]
[Produces("application/json")]
public abstract class BaseApiController : ControllerBase
{
    protected IActionResult CreatedResource<T>(string actionName, object id, T resource)
        => CreatedAtAction(actionName, new { id }, resource);

    protected IActionResult HandleResult<T>(T result) where T : class
        => result == null ? NotFound() : Ok(result);
}
```

### Complete CRUD Controller Example
```csharp
[ApiController]
[Route("api/products")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _productService;
    private readonly ILogger<ProductsController> _logger;

    public ProductsController(
        IProductService productService,
        ILogger<ProductsController> logger)
    {
        _productService = productService;
        _logger = logger;
    }

    /// <summary>
    /// Get all products with optional filtering and pagination
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(PagedResult<ProductDto>), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetAll(
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 10,
        [FromQuery] string? category = null)
    {
        _logger.LogInformation("Fetching products - Page: {Page}, PageSize: {PageSize}", page, pageSize);
        
        var result = await _productService.GetProductsAsync(page, pageSize, category);
        return Ok(result);
    }

    /// <summary>
    /// Get a specific product by ID
    /// </summary>
    [HttpGet("{id:int}")]
    [ProducesResponseType(typeof(ProductDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetById(int id)
    {
        var product = await _productService.GetProductByIdAsync(id);
        
        if (product == null)
        {
            _logger.LogWarning("Product {ProductId} not found", id);
            return NotFound(new { message = $"Product with ID {id} not found" });
        }

        return Ok(product);
    }

    /// <summary>
    /// Create a new product
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(ProductDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ValidationProblemDetails), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Create([FromBody] CreateProductDto dto)
    {
        var product = await _productService.CreateProductAsync(dto);
        
        _logger.LogInformation("Created product {ProductId}", product.Id);
        
        return CreatedAtAction(
            nameof(GetById),
            new { id = product.Id },
            product);
    }

    /// <summary>
    /// Update an existing product
    /// </summary>
    [HttpPut("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateProductDto dto)
    {
        await _productService.UpdateProductAsync(id, dto);
        
        _logger.LogInformation("Updated product {ProductId}", id);
        
        return NoContent();
    }

    /// <summary>
    /// Delete a product
    /// </summary>
    [HttpDelete("{id:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async Task<IActionResult> Delete(int id)
    {
        await _productService.DeleteProductAsync(id);
        
        _logger.LogInformation("Deleted product {ProductId}", id);
        
        return NoContent();
    }

    /// <summary>
    /// Bulk operations example
    /// </summary>
    [HttpPost("bulk")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> BulkCreate([FromBody] IEnumerable<CreateProductDto> dtos)
    {
        var result = await _productService.CreateProductsAsync(dtos);
        return Ok(new { created = result.Count() });
    }
}
```

---

## 4. Dependency Injection

### Service Registration Best Practices
```csharp
// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Scoped: Created once per request (recommended for DB contexts and repositories)
builder.Services.AddScoped<IProductRepository, ProductRepository>();
builder.Services.AddScoped<IProductService, ProductService>();

// Singleton: Created once for application lifetime (thread-safe, stateless)
builder.Services.AddSingleton<ICacheService, MemoryCacheService>();
builder.Services.AddSingleton<IEmailTemplateProvider, EmailTemplateProvider>();

// Transient: Created every time they're requested (lightweight, stateless)
builder.Services.AddTransient<IEmailSender, SmtpEmailSender>();
builder.Services.AddTransient<IPdfGenerator, PdfGenerator>();

// Use extension methods for organization
builder.Services.AddInfrastructure(builder.Configuration);
builder.Services.AddBusinessServices();
```

### Extension Method Pattern
```csharp
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddBusinessServices(this IServiceCollection services)
    {
        // Register all services
        services.AddScoped<IProductService, ProductService>();
        services.AddScoped<IOrderService, OrderService>();
        services.AddScoped<ICustomerService, CustomerService>();
        
        // Add AutoMapper
        services.AddAutoMapper(typeof(MappingProfile));
        
        // Add FluentValidation
        services.AddValidatorsFromAssemblyContaining<CreateProductDtoValidator>();
        
        return services;
    }

    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Database
        services.AddDbContext<AppDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

        // Repositories
        services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
        services.AddScoped<IProductRepository, ProductRepository>();
        
        return services;
    }
}
```

### Constructor Injection (Always Prefer This)
```csharp
public class ProductService : IProductService
{
    private readonly IProductRepository _repository;
    private readonly IMapper _mapper;
    private readonly ILogger<ProductService> _logger;

    // ✅ Constructor injection
    public ProductService(
        IProductRepository repository,
        IMapper mapper,
        ILogger<ProductService> logger)
    {
        _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    // ❌ NEVER use Service Locator pattern
    // var service = httpContext.RequestServices.GetService<IMyService>();
}
```

---

## 5. Data Access & Entity Framework

### DbContext Configuration
```csharp
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }

    public DbSet<Product> Products => Set<Product>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<Customer> Customers => Set<Customer>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        
        // Apply all entity configurations from assembly
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        
        // Global query filters
        modelBuilder.Entity<Product>().HasQueryFilter(p => !p.IsDeleted);
    }

    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        // Auto-update timestamps
        var entries = ChangeTracker.Entries()
            .Where(e => e.Entity is BaseEntity && 
                       (e.State == EntityState.Added || e.State == EntityState.Modified));

        foreach (var entry in entries)
        {
            var entity = (BaseEntity)entry.Entity;
            
            if (entry.State == EntityState.Added)
                entity.CreatedAt = DateTime.UtcNow;
            
            entity.UpdatedAt = DateTime.UtcNow;
        }

        return await base.SaveChangesAsync(cancellationToken);
    }
}
```

### Entity Configuration with Fluent API
```csharp
public class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products");
        
        builder.HasKey(p => p.Id);
        
        builder.Property(p => p.Name)
            .IsRequired()
            .HasMaxLength(200);
        
        builder.Property(p => p.Description)
            .HasMaxLength(1000);
        
        builder.Property(p => p.Price)
            .HasColumnType("decimal(18,2)")
            .IsRequired();
        
        builder.Property(p => p.Sku)
            .IsRequired()
            .HasMaxLength(50);
        
        // Indexes
        builder.HasIndex(p => p.Sku).IsUnique();
        builder.HasIndex(p => p.Name);
        builder.HasIndex(p => p.CategoryId);
        
        // Relationships
        builder.HasOne(p => p.Category)
            .WithMany(c => c.Products)
            .HasForeignKey(p => p.CategoryId)
            .OnDelete(DeleteBehavior.Restrict);
        
        // Seed data
        builder.HasData(
            new Product { Id = 1, Name = "Sample Product", Price = 99.99m, Sku = "SKU001", CategoryId = 1 }
        );
    }
}
```

### Repository Pattern
```csharp
// Generic Repository Interface
public interface IRepository<T> where T : class
{
    Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<IEnumerable<T>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<T> AddAsync(T entity, CancellationToken cancellationToken = default);
    Task UpdateAsync(T entity, CancellationToken cancellationToken = default);
    Task DeleteAsync(int id, CancellationToken cancellationToken = default);
    Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default);
}

// Generic Repository Implementation
public class Repository<T> : IRepository<T> where T : class
{
    protected readonly AppDbContext _context;
    protected readonly DbSet<T> _dbSet;

    public Repository(AppDbContext context)
    {
        _context = context;
        _dbSet = context.Set<T>();
    }

    public virtual async Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _dbSet.FindAsync(new object[] { id }, cancellationToken);
    }

    public virtual async Task<IEnumerable<T>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await _dbSet.AsNoTracking().ToListAsync(cancellationToken);
    }

    public virtual async Task<T> AddAsync(T entity, CancellationToken cancellationToken = default)
    {
        await _dbSet.AddAsync(entity, cancellationToken);
        await _context.SaveChangesAsync(cancellationToken);
        return entity;
    }

    public virtual async Task UpdateAsync(T entity, CancellationToken cancellationToken = default)
    {
        _dbSet.Update(entity);
        await _context.SaveChangesAsync(cancellationToken);
    }

    public virtual async Task DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await GetByIdAsync(id, cancellationToken);
        if (entity != null)
        {
            _dbSet.Remove(entity);
            await _context.SaveChangesAsync(cancellationToken);
        }
    }

    public virtual async Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await GetByIdAsync(id, cancellationToken);
        return entity != null;
    }
}

// Specific Repository with Custom Methods
public interface IProductRepository : IRepository<Product>
{
    Task<IEnumerable<Product>> GetByCategoryAsync(int categoryId);
    Task<Product?> GetBySkuAsync(string sku);
    Task<PagedResult<Product>> GetPagedAsync(int page, int pageSize, string? category = null);
}

public class ProductRepository : Repository<Product>, IProductRepository
{
    public ProductRepository(AppDbContext context) : base(context) { }

    public async Task<IEnumerable<Product>> GetByCategoryAsync(int categoryId)
    {
        return await _dbSet
            .Where(p => p.CategoryId == categoryId)
            .Include(p => p.Category)
            .AsNoTracking()
            .ToListAsync();
    }

    public async Task<Product?> GetBySkuAsync(string sku)
    {
        return await _dbSet
            .FirstOrDefaultAsync(p => p.Sku == sku);
    }

    public async Task<PagedResult<Product>> GetPagedAsync(
        int page, 
        int pageSize, 
        string? category = null)
    {
        var query = _dbSet.AsNoTracking();

        if (!string.IsNullOrEmpty(category))
            query = query.Where(p => p.Category.Name == category);

        var totalCount = await query.CountAsync();

        var products = await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Include(p => p.Category)
            .ToListAsync();

        return new PagedResult<Product>
        {
            Items = products,
            TotalCount = totalCount,
            Page = page,
            PageSize = pageSize
        };
    }
}
```

### Prevent N+1 Query Problems
```csharp
// ❌ Bad: N+1 queries
var orders = await _context.Orders.ToListAsync();
foreach (var order in orders)
{
    // This executes a query for EACH order!
    var customer = await _context.Customers.FindAsync(order.CustomerId);
}

// ✅ Good: Single query with Include
var orders = await _context.Orders
    .Include(o => o.Customer)
    .Include(o => o.OrderItems)
        .ThenInclude(oi => oi.Product)
    .ToListAsync();

// ✅ Use AsNoTracking for read-only queries
var products = await _context.Products
    .AsNoTracking()
    .Where(p => p.CategoryId == categoryId)
    .ToListAsync();

// ✅ Use projection when you don't need the entire entity
var productDtos = await _context.Products
    .Select(p => new ProductDto
    {
        Id = p.Id,
        Name = p.Name,
        Price = p.Price
    })
    .ToListAsync();
```

---

## 6. Authentication & Security

### JWT Authentication Setup
```csharp
// appsettings.json
{
  "JwtSettings": {
    "SecretKey": "your-secret-key-at-least-32-characters-long-change-in-production",
    "Issuer": "MyWebApi",
    "Audience": "MyWebApiClients",
    "ExpirationMinutes": 60,
    "RefreshTokenExpirationDays": 7
  }
}

// Program.cs
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["JwtSettings:Issuer"],
        ValidAudience = builder.Configuration["JwtSettings:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(builder.Configuration["JwtSettings:SecretKey"]!)),
        ClockSkew = TimeSpan.Zero // Remove default 5 minute tolerance
    };

    options.Events = new JwtBearerEvents
    {
        OnAuthenticationFailed = context =>
        {
            if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
            {
                context.Response.Headers.Add("Token-Expired", "true");
            }
            return Task.CompletedTask;
        }
    };
});

app.UseAuthentication();
app.UseAuthorization();
```

### Token Service
```csharp
public interface ITokenService
{
    string GenerateAccessToken(User user);
    string GenerateRefreshToken();
    ClaimsPrincipal? GetPrincipalFromExpiredToken(string token);
}

public class TokenService : ITokenService
{
    private readonly IConfiguration _configuration;

    public TokenService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public string GenerateAccessToken(User user)
    {
        var securityKey = new SymmetricSecurityKey(
            Encoding.UTF8.GetBytes(_configuration["JwtSettings:SecretKey"]!));
        
        var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim(ClaimTypes.Email, user.Email),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var token = new JwtSecurityToken(
            issuer: _configuration["JwtSettings:Issuer"],
            audience: _configuration["JwtSettings:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(
                int.Parse(_configuration["JwtSettings:ExpirationMinutes"]!)),
            signingCredentials: credentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);
    }

    public string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);
        return Convert.ToBase64String(randomNumber);
    }

    public ClaimsPrincipal? GetPrincipalFromExpiredToken(string token)
    {
        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateAudience = false,
            ValidateIssuer = false,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(_configuration["JwtSettings:SecretKey"]!)),
            ValidateLifetime = false // Don't validate lifetime for refresh
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out var securityToken);
        
        if (securityToken is not JwtSecurityToken jwtSecurityToken ||
            !jwtSecurityToken.Header.Alg.Equals(SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase))
        {
            throw new SecurityTokenException("Invalid token");
        }

        return principal;
    }
}
```

### Password Hashing (NEVER store plain text!)
```csharp
public interface IPasswordHasher
{
    string HashPassword(string password);
    bool VerifyPassword(string password, string hash);
}

// Using BCrypt (recommended)
public class BcryptPasswordHasher : IPasswordHasher
{
    public string HashPassword(string password)
    {
        return BCrypt.Net.BCrypt.HashPassword(password, workFactor: 12);
    }

    public bool VerifyPassword(string password, string hash)
    {
        return BCrypt.Net.BCrypt.Verify(password, hash);
    }
}
```

### Authorization Policies
```csharp
// Program.cs
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => 
        policy.RequireRole("Admin"));
    
    options.AddPolicy("CanEditProducts", policy => 
        policy.RequireClaim("Permission", "Products.Edit"));
    
    options.AddPolicy("MinimumAge", policy => 
        policy.Requirements.Add(new MinimumAgeRequirement(18)));
});

// Controller usage
[Authorize(Policy = "AdminOnly")]
[HttpDelete("{id}")]
public async Task<IActionResult> Delete(int id)
{
    await _productService.DeleteProductAsync(id);
    return NoContent();
}

[Authorize(Roles = "Admin,Manager")]
[HttpPut("{id}")]
public async Task<IActionResult> Update(int id, UpdateProductDto dto)
{
    // Only Admin or Manager can update
}
```

### CORS Configuration
```csharp
// Program.cs
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins", policy =>
    {
        policy.WithOrigins(
                "https://yourdomain.com",
                "https://app.yourdomain.com")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });

    // For development only
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Apply CORS before UseAuthorization
app.UseCors("AllowSpecificOrigins");
```

---

## 7. Error Handling & Validation

### Global Exception Handling Middleware
```csharp
public class GlobalExceptionHandlerMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<GlobalExceptionHandlerMiddleware> _logger;

    public GlobalExceptionHandlerMiddleware(
        RequestDelegate next,
        ILogger<GlobalExceptionHandlerMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            await HandleExceptionAsync(context, ex);
        }
    }

    private async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        context.Response.ContentType = "application/json";
        
        var response = exception switch
        {
            NotFoundException notFound => new ErrorResponse
            {
                StatusCode = StatusCodes.Status404NotFound,
                Message = notFound.Message,
                Details = notFound.Details
            },
            ValidationException validation => new ErrorResponse
            {
                StatusCode = StatusCodes.Status400BadRequest,
                Message = "Validation failed",
                Errors = validation.Errors
            },
            UnauthorizedAccessException _ => new ErrorResponse
            {
                StatusCode = StatusCodes.Status401Unauthorized,
                Message = "Unauthorized access"
            },
            _ => new ErrorResponse
            {
                StatusCode = StatusCodes.Status500InternalServerError,
                Message = "An unexpected error occurred"
            }
        };

        context.Response.StatusCode = response.StatusCode;

        // Log error
        _logger.LogError(exception, 
            "Error occurred: {Message}. TraceId: {TraceId}", 
            exception.Message, 
            context.TraceIdentifier);

        // Don't expose internal errors in production
        if (response.StatusCode == 500 && !context.RequestServices
            .GetRequiredService<IWebHostEnvironment>().IsDevelopment())
        {
            response.Message = "An internal server error occurred";
            response.Details = null;
        }

        response.TraceId = Activity.Current?.Id ?? context.TraceIdentifier;

        await context.Response.WriteAsJsonAsync(response);
    }
}

public class ErrorResponse
{
    public int StatusCode { get; set; }
    public string Message { get; set; } = string.Empty;
    public string? Details { get; set; }
    public Dictionary<string, string[]>? Errors { get; set; }
    public string? TraceId { get; set; }
}

// Register in Program.cs
app.UseMiddleware<GlobalExceptionHandlerMiddleware>();
```

### Custom Exceptions
```csharp
public class NotFoundException : Exception
{
    public string? Details { get; }

    public NotFoundException(string message, string? details = null)
        : base(message)
    {
        Details = details;
    }

    public static NotFoundException ForEntity<T>(int id)
        => new($"{typeof(T).Name} with ID {id} was not found");
}

public class ValidationException : Exception
{
    public Dictionary<string, string[]> Errors { get; }

    public ValidationException(Dictionary<string, string[]> errors)
        : base("One or more validation errors occurred")
    {
        Errors = errors;
    }
}

public class BusinessRuleViolationException : Exception
{
    public BusinessRule ViolatedRule { get; }

    public BusinessRuleViolationException(BusinessRule rule, string message)
        : base(message)
    {
        ViolatedRule = rule;
    }
}
```

### FluentValidation Integration
```csharp
// DTO Validator
public class CreateProductDtoValidator : AbstractValidator<CreateProductDto>
{
    public CreateProductDtoValidator()
    {
        RuleFor(x => x.Name)
            .NotEmpty().WithMessage("Product name is required")
            .MaximumLength(200).WithMessage("Product name must not exceed 200 characters")
            .Must(BeAValidProductName).WithMessage("Product name contains invalid characters");

        RuleFor(x => x.Price)
            .GreaterThan(0).WithMessage("Price must be greater than zero")
            .LessThan(1000000).WithMessage("Price must be less than 1,000,000");

        RuleFor(x => x.Sku)
            .NotEmpty().WithMessage("SKU is required")
            .Matches(@"^[A-Z0-9-]+$").WithMessage("SKU must contain only uppercase letters, numbers, and hyphens");

        RuleFor(x => x.CategoryId)
            .GreaterThan(0).WithMessage("Valid category is required");

        RuleFor(x => x.Description)
            .MaximumLength(1000).WithMessage("Description must not exceed 1000 characters");
    }

    private bool BeAValidProductName(string name)
    {
        return !string.IsNullOrWhiteSpace(name) && 
               !name.Contains('<') && 
               !name.Contains('>');
    }
}

// Program.cs
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<CreateProductDtoValidator>();
```

---

## 8. Async Programming

### Always Use Async for I/O Operations
```csharp
// ✅ Correct
public async Task<Product> GetProductAsync(int id)
{
    return await _repository.GetByIdAsync(id);
}

// ❌ Wrong - Synchronous database call
public Product GetProduct(int id)
{
    return _context.Products.Find(id); // Blocks thread!
}

// ❌ Wrong - Blocking async with .Result or .Wait()
public Product GetProduct(int id)
{
    return _repository.GetByIdAsync(id).Result; // Can cause deadlocks!
}
```

### Avoid Async Void
```csharp
// ✅ Correct
public async Task ProcessOrderAsync(Order order)
{
    await _orderService.ProcessAsync(order);
}

// ❌ Wrong - exceptions can't be caught!
public async void ProcessOrder(Order order) // Only for event handlers!
{
    await _orderService.ProcessAsync(order);
}
```

### Use ConfigureAwait in Library Code
```csharp
// In library/service code (not controllers)
public async Task<Product> GetProductAsync(int id)
{
    var entity = await _repository
        .GetByIdAsync(id)
        .ConfigureAwait(false); // Don't capture context
    
    return _mapper.Map<Product>(entity);
}

// In controllers, no need for ConfigureAwait
public async Task<IActionResult> GetProduct(int id)
{
    var product = await _productService.GetProductAsync(id);
    return Ok(product);
}
```

### Parallel Operations When Appropriate
```csharp
// ✅ Run independent operations in parallel
public async Task<DashboardData> GetDashboardDataAsync()
{
    var productsTask = _productService.GetTotalCountAsync();
    var ordersTask = _orderService.GetRecentOrdersAsync();
    var revenueTask = _reportService.GetTotalRevenueAsync();

    await Task.WhenAll(productsTask, ordersTask, revenueTask);

    return new DashboardData
    {
        TotalProducts = await productsTask,
        RecentOrders = await ordersTask,
        TotalRevenue = await revenueTask
    };
}
```

### CancellationToken Support
```csharp
// Always accept and propagate CancellationToken
public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
{
    var products = await _productService.GetAllAsync(cancellationToken);
    return Ok(products);
}

public async Task<IEnumerable<Product>> GetAllAsync(CancellationToken cancellationToken = default)
{
    return await _repository.GetAllAsync(cancellationToken);
}

// Example: Long running operation with cancellation
public async Task<Report> GenerateReportAsync(int year, CancellationToken cancellationToken)
{
    var data = new List<ReportItem>();
    
    for (int month = 1; month <= 12; month++)
    {
        cancellationToken.ThrowIfCancellationRequested();
        
        var monthData = await _repository.GetMonthlyDataAsync(year, month, cancellationToken);
        data.AddRange(monthData);
    }
    
    return new Report { Items = data };
}
```

---

## 9. Performance Optimization

### Response Caching
```csharp
// Program.cs
builder.Services.AddResponseCaching();

app.UseResponseCaching();
app.Use(async (context, next) =>
{
    context.Response.GetTypedHeaders().CacheControl =
        new Microsoft.Net.Http.Headers.CacheControlHeaderValue()
        {
            Public = true,
            MaxAge = TimeSpan.FromSeconds(10)
        };
    await next();
});

// Controller
[HttpGet]
[ResponseCache(Duration = 60, Location = ResponseCacheLocation.Any, VaryByQueryKeys = new[] { "category" })]
public async Task<IActionResult> GetAll([FromQuery] string? category)
{
    var products = await _productService.GetAllAsync(category);
    return Ok(products);
}

// Cache profiles (in Program.cs)
builder.Services.AddControllers(options =>
{
    options.CacheProfiles.Add("Default30", new CacheProfile { Duration = 30 });
    options.CacheProfiles.Add("NoCache", new CacheProfile { NoStore = true });
});

[HttpGet]
[ResponseCache(CacheProfileName = "Default30")]
public async Task<IActionResult> GetCategories()
{
    var categories = await _categoryService.GetAllAsync();
    return Ok(categories);
}
```

### Memory Caching
```csharp
public interface ICacheService
{
    Task<T?> GetAsync<T>(string key);
    Task SetAsync<T>(string key, T value, TimeSpan? expiration = null);
    Task RemoveAsync(string key);
}

public class MemoryCacheService : ICacheService
{
    private readonly IMemoryCache _cache;

    public MemoryCacheService(IMemoryCache cache)
    {
        _cache = cache;
    }

    public Task<T?> GetAsync<T>(string key)
    {
        _cache.TryGetValue(key, out T? value);
        return Task.FromResult(value);
    }

    public Task SetAsync<T>(string key, T value, TimeSpan? expiration = null)
    {
        var cacheOptions = new MemoryCacheEntryOptions
        {
            AbsoluteExpirationRelativeToNow = expiration ?? TimeSpan.FromMinutes(5)
        };

        _cache.Set(key, value, cacheOptions);
        return Task.CompletedTask;
    }

    public Task RemoveAsync(string key)
    {
        _cache.Remove(key);
        return Task.CompletedTask;
    }
}

// Usage in service
public async Task<IEnumerable<Category>> GetCategoriesAsync()
{
    const string cacheKey = "all_categories";
    
    var cached = await _cacheService.GetAsync<IEnumerable<Category>>(cacheKey);
    if (cached != null)
        return cached;

    var categories = await _repository.GetAllAsync();
    await _cacheService.SetAsync(cacheKey, categories, TimeSpan.FromHours(1));
    
    return categories;
}
```

### Pagination
```csharp
public class PagedResult<T>
{
    public IEnumerable<T> Items { get; set; } = Enumerable.Empty<T>();
    public int TotalCount { get; set; }
    public int Page { get; set; }
    public int PageSize { get; set; }
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
    public bool HasPrevious => Page > 1;
    public bool HasNext => Page < TotalPages;
}

public class PaginationParameters
{
    private const int MaxPageSize = 100;
    private int _pageSize = 10;

    public int Page { get; set; } = 1;

    public int PageSize
    {
        get => _pageSize;
        set => _pageSize = value > MaxPageSize ? MaxPageSize : value;
    }
}

// Controller
[HttpGet]
public async Task<ActionResult<PagedResult<ProductDto>>> GetAll(
    [FromQuery] PaginationParameters parameters)
{
    var result = await _productService.GetPagedAsync(parameters.Page, parameters.PageSize);
    
    // Add pagination metadata to response headers
    Response.Headers.Add("X-Pagination", JsonSerializer.Serialize(new
    {
        result.TotalCount,
        result.TotalPages,
        result.Page,
        result.PageSize
    }));

    return Ok(result);
}
```

### Response Compression
```csharp
// Program.cs
builder.Services.AddResponseCompression(options =>
{
    options.EnableForHttps = true;
    options.Providers.Add<GzipCompressionProvider>();
    options.Providers.Add<BrotliCompressionProvider>();
});

builder.Services.Configure<GzipCompressionProviderOptions>(options =>
{
    options.Level = System.IO.Compression.CompressionLevel.Fastest;
});

app.UseResponseCompression();
```

### Database Performance
```csharp
// Use AsNoTracking for read-only queries
var products = await _context.Products
    .AsNoTracking()
    .Where(p => p.CategoryId == categoryId)
    .ToListAsync();

// Use projection instead of full entities
var productNames = await _context.Products
    .Select(p => new { p.Id, p.Name })
    .ToListAsync();

// Avoid loading unnecessary data
var orders = await _context.Orders
    .Include(o => o.Customer) // Only include what you need
    .Where(o => o.CreatedAt >= DateTime.UtcNow.AddDays(-30))
    .ToListAsync();

// Use compiled queries for frequently executed queries
private static readonly Func<AppDbContext, int, Task<Product?>> GetProductByIdCompiled =
    EF.CompileAsyncQuery((AppDbContext context, int id) =>
        context.Products.FirstOrDefault(p => p.Id == id));

public async Task<Product?> GetProductByIdAsync(int id)
{
    return await GetProductByIdCompiled(_context, id);
}
```

---

## 10. Logging & Monitoring

### Structured Logging with Serilog
```csharp
// Install: Serilog.AspNetCore, Serilog.Sinks.Console, Serilog.Sinks.File

// Program.cs
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog
builder.Host.UseSerilog((context, configuration) =>
{
    configuration
        .ReadFrom.Configuration(context.Configuration)
        .Enrich.FromLogContext()
        .Enrich.WithProperty("Application", "MyWebApi")
        .Enrich.WithProperty("Environment", context.HostingEnvironment.EnvironmentName)
        .WriteCons()
        .WriteTo.File(
            path: "logs/log-.txt",
            rollingInterval: RollingInterval.Day,
            retainedFileCountLimit: 7,
            outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}");
});

// appsettings.json
{
  "Serilog": {
    "MinimumLevel": {
      "Default": "Information",
      "Override": {
        "Microsoft": "Warning",
        "Microsoft.EntityFrameworkCore": "Warning",
        "System": "Warning"
      }
    }
  }
}
```

### Effective Logging in Services
```csharp
public class ProductService : IProductService
{
    private readonly IProductRepository _repository;
    private readonly ILogger<ProductService> _logger;

    public ProductService(IProductRepository repository, ILogger<ProductService> logger)
    {
        _repository = repository;
        _logger = logger;
    }

    public async Task<Product> CreateProductAsync(CreateProductDto dto)
    {
        // Use structured logging with named parameters
        _logger.LogInformation("Creating product with SKU: {Sku}, Name: {Name}", dto.Sku, dto.Name);

        try
        {
            var product = _mapper.Map<Product>(dto);
            var created = await _repository.AddAsync(product);

            _logger.LogInformation("Successfully created product {ProductId} with SKU {Sku}", 
                created.Id, created.Sku);

            return created;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error creating product with SKU: {Sku}", dto.Sku);
            throw;
        }
    }

    public async Task<Product?> GetProductAsync(int id)
    {
        _logger.LogDebug("Fetching product {ProductId}", id);

        var product = await _repository.GetByIdAsync(id);

        if (product == null)
        {
            _logger.LogWarning("Product {ProductId} not found", id);
        }

        return product;
    }
}
```

### Log Levels Guidelines
```csharp
// Trace: Very detailed, use for debugging
_logger.LogTrace("Entering method GetProductAsync with id: {Id}", id);

// Debug: Internal system events
_logger.LogDebug("Cache miss for key: {CacheKey}", cacheKey);

// Information: General flow, business events
_logger.LogInformation("User {UserId} created order {OrderId}", userId, orderId);

// Warning: Abnormal but expected events
_logger.LogWarning("Product {ProductId} inventory low: {Quantity} units remaining", productId, quantity);

// Error: Errors that don't stop the application
_logger.LogError(exception, "Failed to process payment for order {OrderId}", orderId);

// Critical: Catastrophic failures
_logger.LogCritical("Database connection failed. Application cannot continue.");
```

### Request/Response Logging Middleware
```csharp
public class RequestResponseLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestResponseLoggingMiddleware> _logger;

    public RequestResponseLoggingMiddleware(
        RequestDelegate next,
        ILogger<RequestResponseLoggingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Log request
        _logger.LogInformation(
            "HTTP {Method} {Path} started. TraceId: {TraceId}",
            context.Request.Method,
            context.Request.Path,
            context.TraceIdentifier);

        var stopwatch = Stopwatch.StartNew();

        try
        {
            await _next(context);
        }
        finally
        {
            stopwatch.Stop();

            // Log response
            _logger.LogInformation(
                "HTTP {Method} {Path} completed with status {StatusCode} in {ElapsedMs}ms",
                context.Request.Method,
                context.Request.Path,
                context.Response.StatusCode,
                stopwatch.ElapsedMilliseconds);
        }
    }
}
```

---

## 11. API Documentation

### Swagger/OpenAPI Configuration
```csharp
// Program.cs
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "My Web API",
        Version = "v1",
        Description = "A comprehensive ASP.NET Core Web API",
        Contact = new OpenApiContact
        {
            Name = "Your Name",
            Email = "your.email@example.com",
            Url = new Uri("https://example.com")
        }
    });

    // Add JWT authentication support
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "Enter 'Bearer' [space] and then your token"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });

    // Include XML comments
    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    options.IncludeXmlComments(xmlPath);
});

// Enable Swagger in all environments (be cautious in production)
app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
    options.RoutePrefix = string.Empty; // Swagger UI at root
});
```

### XML Documentation
```csharp
// Enable in .csproj
<PropertyGroup>
  <GenerateDocumentationFile>true</GenerateDocumentationFile>
  <NoWarn>$(NoWarn);1591</NoWarn>
</PropertyGroup>

/// <summary>
/// Gets a product by its unique identifier
/// </summary>
/// <param name="id">The product ID</param>
/// <returns>The product if found, otherwise 404</returns>
/// <response code="200">Returns the requested product</response>
/// <response code="404">If the product is not found</response>
[HttpGet("{id}")]
[ProducesResponseType(typeof(ProductDto), StatusCodes.Status200OK)]
[ProducesResponseType(StatusCodes.Status404NotFound)]
public async Task<IActionResult> GetById(int id)
{
    var product = await _productService.GetProductByIdAsync(id);
    return product == null ? NotFound() : Ok(product);
}
```

---

## 12. Testing

### Unit Testing with NUnit
```csharp
[TestFixture]
public class ProductServiceTests
{
    private Mock<IProductRepository> _mockRepository;
    private Mock<IMapper> _mockMapper;
    private Mock<ILogger<ProductService>> _mockLogger;
    private ProductService _service;

    [SetUp]
    public void Setup()
    {
        _mockRepository = new Mock<IProductRepository>();
        _mockMapper = new Mock<IMapper>();
        _mockLogger = new Mock<ILogger<ProductService>>();
        _service = new ProductService(
            _mockRepository.Object,
            _mockMapper.Object,
            _mockLogger.Object);
    }

    [Test]
    public async Task GetProductByIdAsync_WhenProductExists_ReturnsProduct()
    {
        // Arrange
        var productId = 1;
        var expectedProduct = new Product { Id = productId, Name = "Test Product" };
        
        _mockRepository
            .Setup(r => r.GetByIdAsync(productId, It.IsAny<CancellationToken>()))
            .ReturnsAsync(expectedProduct);

        // Act
        var result = await _service.GetProductByIdAsync(productId);

        // Assert
        result.Should().NotBeNull();
        result.Id.Should().Be(productId);
        _mockRepository.Verify(r => r.GetByIdAsync(productId, It.IsAny<CancellationToken>()), Times.Once);
    }

    [Test]
    public async Task GetProductByIdAsync_WhenProductDoesNotExist_ReturnsNull()
    {
        // Arrange
        var productId = 999;
        
        _mockRepository
            .Setup(r => r.GetByIdAsync(productId, It.IsAny<CancellationToken>()))
            .ReturnsAsync((Product?)null);

        // Act
        var result = await _service.GetProductByIdAsync(productId);

        // Assert
        result.Should().BeNull();
    }

    [Test]
    public async Task CreateProductAsync_WithValidData_CreatesProduct()
    {
        // Arrange
        var dto = new CreateProductDto { Name = "New Product", Price = 99.99m, Sku = "SKU001" };
        var product = new Product { Id = 1, Name = dto.Name, Price = dto.Price };
        
        _mockMapper.Setup(m => m.Map<Product>(dto)).Returns(product);
        _mockRepository
            .Setup(r => r.AddAsync(It.IsAny<Product>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(product);

        // Act
        var result = await _service.CreateProductAsync(dto);

        // Assert
        result.Should().NotBeNull();
        result.Id.Should().Be(1);
        _mockRepository.Verify(r => r.AddAsync(It.IsAny<Product>(), It.IsAny<CancellationToken>()), Times.Once);
    }
}
```

### Integration Testing
```csharp
public class ProductsIntegrationTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly HttpClient _client;
    private readonly WebApplicationFactory<Program> _factory;

    public ProductsIntegrationTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory.WithWebHostBuilder(builder =>
        {
            builder.ConfigureServices(services =>
            {
                // Remove production DbContext
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<AppDbContext>));
                if (descriptor != null)
                    services.Remove(descriptor);

                // Add in-memory database for testing
                services.AddDbContext<AppDbContext>(options =>
                {
                    options.UseInMemoryDatabase("TestDb");
                });
            });
        });

        _client = _factory.CreateClient();
    }

    [Test]
    public async Task GetProducts_ReturnsSuccessStatusCode()
    {
        // Act
        var response = await _client.GetAsync("/api/products");

        // Assert
        response.EnsureSuccessStatusCode();
        response.Content.Headers.ContentType?.ToString().Should().Be("application/json; charset=utf-8");
    }

    [Test]
    public async Task CreateProduct_WithValidData_ReturnsCreated()
    {
        // Arrange
        var newProduct = new
        {
            name = "Test Product",
            price = 29.99,
            sku = "TEST001",
            categoryId = 1
        };

        // Act
        var response = await _client.PostAsJsonAsync("/api/products", newProduct);

        // Assert
        response.StatusCode.Should().Be(HttpStatusCode.Created);
        response.Headers.Location.Should().NotBeNull();
    }
}
```

---

## Summary Checklist

### API Design
- ✅ RESTful conventions followed
- ✅ Proper HTTP methods and status codes
- ✅ Consistent resource naming
- ✅ API versioning implemented

### Architecture
- ✅ Clean separation of concerns
- ✅ Dependency injection used properly
- ✅ Repository pattern for data access
- ✅ DTOs for data transfer

### Security
- ✅ JWT authentication configured
- ✅ Passwords hashed (never plain text)
- ✅ CORS properly configured
- ✅ HTTPS enforced
- ✅ Authorization policies defined

### Performance
- ✅ Async/await used throughout
- ✅ Response caching implemented
- ✅ Pagination for large datasets
- ✅ No N+1 queries
- ✅ Compression enabled

### Error Handling
- ✅ Global exception handler
- ✅ Custom exception types
- ✅ Validation with FluentValidation
- ✅ Proper error responses

### Logging & Monitoring
 - ✅ Structured logging with Serilog
- ✅ Appropriate log levels
- ✅ Request/response logging
- ✅ Performance monitoring

### Documentation
- ✅ Swagger/OpenAPI configured
- ✅ XML documentation comments
- ✅ Clear API descriptions

### Testing
- ✅ Unit tests with good coverage
- ✅ Integration tests
- ✅ Repository tests with in-memory DB
- ✅ Tests follow AAA pattern

---

## Additional Resources

- [ASP.NET Core Best Practices](https://learn.microsoft.com/en-us/aspnet/core/fundamentals/best-practices)
- [REST API Guidelines](https://learn.microsoft.com/en-us/azure/architecture/best-practices/api-design)
- [Entity Framework Core Performance](https://learn.microsoft.com/en-us/ef/core/performance/)
- [OWASP Security Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/DotNet_Security_Cheat_Sheet.html)
- [Async Programming Patterns](https://learn.microsoft.com/en-us/dotnet/csharp/asynchronous-programming/)
