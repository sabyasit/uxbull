import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UploadComponent } from './upload/upload.component';
import { ResumeViewerComponent } from './resume-viewer/resume-viewer.component';
import { ResumeViewer2Component } from './resume-viewer-2/resume-viewer-2.component';

const routes: Routes = [
    { path: '', component: UploadComponent, pathMatch: 'full' },
    { path: 'upload', component: UploadComponent },
    { path: 'resume', component: ResumeViewerComponent },
    { path: 'resume-viewer-2', component: ResumeViewer2Component }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class AppRoutingModule { }
