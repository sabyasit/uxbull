import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ResumeViewerComponent } from './resume-viewer/resume-viewer.component';
import { ResumeViewer2Component } from './resume-viewer-2/resume-viewer-2.component';
import { UploadComponent } from './upload/upload.component';

import { AppRoutingModule } from './app-routing.module';

@NgModule({
  declarations: [
    AppComponent,
    ResumeViewerComponent,
    ResumeViewer2Component,
    UploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
