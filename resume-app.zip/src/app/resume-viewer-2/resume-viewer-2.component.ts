import { Component } from '@angular/core';

@Component({
    selector: 'app-resume-viewer-2',
    templateUrl: './resume-viewer-2.component.html',
    styleUrls: ['./resume-viewer-2.component.css']
})
export class ResumeViewer2Component {

}
