import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent {

  constructor(private router: Router) { }

  tasks: any[] = [
    {
      id: 1,
      name: 'Uploading your resume',
      progress: 0,
      status: 0,
      msg: []
    },
    {
      id: 2,
      name: 'Analysing your resume',
      progress: 0,
      status: 0,
      msg: ['Analysing your resume']
    },
    {
      id: 3,
      name: 'Generating recommendations',
      progress: 0,
      status: 0,
      msg: []
    },
    {
      id: 4,
      name: 'Resume format suggestions',
      progress: 0,
      status: 0,
      msg: []
    }
  ];
  selectedFile: File | null = null;
  formatSelection: number = 0;

  handleFileSelection(event: Event) {
    const fileInput = event.target as HTMLInputElement;
    const file = fileInput.files?.[0];
    if (file) {
      this.selectedFile = file;
      this.startTasks();
    }
  }

  async startTasks() {
    for (const task of this.tasks) {
      await this.processTasks(task);
    }
  }

  async processTasks(task: any) {
    if (task.id === 1) {
      task.status = 1;
      await new Promise(resolve => setTimeout(resolve, 1000));
      task.progress = 100;
    }
    if (task.id === 2) {
      task.status = 1;
      await new Promise(resolve => setTimeout(resolve, 1000));
      task.progress = 100;
    }
    if (task.id === 3) {
      task.status = 1;
      await new Promise(resolve => setTimeout(resolve, 1000));
      task.progress = 100;
    }
    if (task.id === 4) {
      task.status = 1;
      await new Promise(resolve => setTimeout(resolve, 1000));
      task.progress = 100;
    }
  }

  onContinue() {
    this.router.navigate(['/resume']);
  }
}
