import { Component, Input, OnInit } from '@angular/core';

export interface HtmlTreeNode {
    id: string;
    name: string;
    expanded: boolean;
    children?: HtmlTreeNode[];
}

@Component({
    selector: 'app-html-tree-graph',
    templateUrl: './html-tree-graph.component.html',
    styleUrls: ['./html-tree-graph.component.css']
})
export class HtmlTreeGraphComponent implements OnInit {
    @Input() data: any;
    public treeData!: HtmlTreeNode;

    ngOnInit() {
        if (this.data) {
            this.treeData = this.buildTree(this.data);
        }
    }

    buildTree(data: any): HtmlTreeNode {
        const rootId = data.roadmapId || 'root';
        const root: HtmlTreeNode = {
            id: rootId,
            name: data.title || 'Roadmap',
            expanded: true,
            children: []
        };

        if (data.categories) {
            data.categories.forEach((cat: any) => {
                const catNode: HtmlTreeNode = {
                    id: cat.categoryId,
                    name: cat.name,
                    expanded: true, // Default expand one level
                    children: []
                };
                if (cat.topics) {
                    cat.topics.forEach((topic: any) => {
                        const topicNode: HtmlTreeNode = {
                            id: topic.topicId,
                            name: topic.name,
                            expanded: true,
                            children: []
                        };
                        if (topic.subtopics) {
                            topic.subtopics.forEach((subtopic: any, idx: number) => {
                                topicNode.children!.push({
                                    id: `${topic.topicId}-sub-${idx}`,
                                    name: subtopic.name,
                                    expanded: true
                                });
                            });
                        }
                        if (topicNode.children!.length === 0) {
                            delete topicNode.children;
                        }
                        catNode.children!.push(topicNode);
                    });
                }
                root.children!.push(catNode);
            });
        }
        return root;
    }

    toggleNode(node: HtmlTreeNode) {
        if (node.children && node.children.length > 0) {
            node.expanded = !node.expanded;
        }
    }
}
