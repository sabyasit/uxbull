import { Component } from '@angular/core';

export interface JobMatchAnalysis {
    candidateName: string;
    jobTitle: string;
    isMatch: boolean;
    overallScore: number;
    confidence: string;
    summary: string;
    details: {
        skillsMatch: {
            score: number;
            matchedSkills: string[];
            missingSkills: string[];
            additionalSkills: string[];
        };
        experienceMatch: {
            score: number;
            yearsRequired: number;
            yearsCandidate: number;
            relevantExperience: string[];
        };
    };
    strengths: string[];
    gaps: string[];
    recommendations: string[];
    reasoning: string;
}

@Component({
    selector: 'app-job-match',
    templateUrl: './job-match.component.html',
    styleUrls: ['./job-match.component.css']
})
export class JobMatchComponent {

    dummyAnalyses: JobMatchAnalysis[] = [
        {
            candidateName: "John Doe",
            jobTitle: "Senior Frontend Engineer",
            isMatch: true,
            overallScore: 85,
            confidence: "High",
            summary: "Your profile is a very strong candidate for this position. You match 90% of the required technical skills, specifically in Angular and TypeScript.",
            details: {
                skillsMatch: {
                    score: 9,
                    matchedSkills: ["Angular", "TypeScript", "SCSS", "RxJS"],
                    missingSkills: ["GraphQL", "AWS"],
                    additionalSkills: ["React", "Python"]
                },
                experienceMatch: {
                    score: 10,
                    yearsRequired: 5,
                    yearsCandidate: 7,
                    relevantExperience: ["Senior Frontend Engineer at TechCorp", "UI Developer at WebSolutions"]
                }
            },
            strengths: ["Expertise in Angular 14+", "Senior level experience (5+ years)", "Strong background in UI/UX Design"],
            gaps: ["AWS / Cloud Certification", "Experience with GraphQL"],
            recommendations: ["Add a section highlighting your REST API knowledge to mitigate the GraphQL gap.", "Mention any informal cloud deployment experience in your project descriptions."],
            reasoning: "The matching engine weighted technical skills at 50% and experience duration at 30%. While your years of experience exceed the requirement, the absence of specific cloud keywords lowered the overall match score slightly."
        },
        {
            candidateName: "Jane Smith",
            jobTitle: "Senior Frontend Engineer",
            isMatch: true,
            overallScore: 92,
            confidence: "Very High",
            summary: "Excellent match! Your skill set aligns almost perfectly with the job description. The only minor deviation is in domain-specific knowledge.",
            details: {
                skillsMatch: {
                    score: 9.5,
                    matchedSkills: ["Angular", "TypeScript", "RxJS", "NGRX", "Jasmine"],
                    missingSkills: ["FinTech Domain Knowledge"],
                    additionalSkills: ["Node.js", "Docker"]
                },
                experienceMatch: {
                    score: 9,
                    yearsRequired: 4,
                    yearsCandidate: 6,
                    relevantExperience: ["Frontend Lead at BankSys", "Developer at CryptoStart"]
                }
            },
            strengths: ["Perfect tech stack match", "Leadership experience identified", "Strong testing background"],
            gaps: ["Specific FinTech regulation knowledge"],
            recommendations: ["Highlight any financial projects even if freelance.", "Emphasize security best practices in previous roles."],
            reasoning: "Technical score is near perfect. The slight deduction comes from the domain-specific requirement which is listed as 'preferred' rather than 'required'."
        },
        {
            candidateName: "John Moddy",
            jobTitle: "Senior Frontend Engineer",
            isMatch: false,
            overallScore: 45,
            confidence: "Medium",
            summary: "This role seems to be a mismatch for your current profile. It requires heavy backend focus which is not prominent in your CV.",
            details: {
                skillsMatch: {
                    score: 4,
                    matchedSkills: ["TypeScript", "Git"],
                    missingSkills: ["Java", "Spring Boot", "Microservices", "Kafka", "PostgreSQL"],
                    additionalSkills: ["Angular", "CSS", "HTML"]
                },
                experienceMatch: {
                    score: 5,
                    yearsRequired: 3,
                    yearsCandidate: 4,
                    relevantExperience: ["Fullstack (Frontend heavy) at StartupObs"]
                }
            },
            strengths: ["Good general software engineering practices", "Familiarity with Agile"],
            gaps: ["Missing core backend technologies (Java/Spring)", "No database design experience listed"],
            recommendations: ["This role might be too backend-heavy.", "Consider applying for 'Fullstack' roles that emphasize Frontend if you want to transition."],
            reasoning: "The job description is for a Backend Engineer, while your CV is 80% Frontend focused. The keyword overlap is minimal outside of generic terms."
        }
    ];

    //currentAnalysis: JobMatchAnalysis | null = this.dummyAnalyses[0];

    getScoreColor(score: number): string {
        if (score >= 80) return '#16a34a'; // Green/Success
        if (score >= 50) return '#d97706'; // Orange/Warning
        return '#dc2626'; // Red/Danger
    }

}
